<?php
$con=mysqli_connect("localhost", "root", "123", "ethnotech1");
if(mysqli_connect_errno())
{
echo "Connection Fail".mysqli_connect_error();
}
?>